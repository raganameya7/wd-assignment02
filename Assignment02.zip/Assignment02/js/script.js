/* movie id 1 to 8 is position 0 to 7 in these arrays */
var titles = ["Starlight Rescue", "The Tiny Orchestra", "Laugh Track", "Bad Wedding Planner",
 "Iron Meridian", "Skyline Runners", "Paper Lanterns", "The Last Ledger"];
var prices = [12, 12, 14, 15, 16, 15, 15, 16];


/* ---------- Recommendation page ---------- */

function recommend() {
  var genre = document.getElementById("genre").value;
  var age = document.getElementById("age").value;
  var viewing = document.getElementById("viewing").value;
  var errMsg = "";
  var movieId;

  if (genre == "") {
    errMsg += "Please choose a genre.\n";
  }
  if (age == "") {
    errMsg += "Please choose an age group.\n";
  }
  if (viewing == "") {
    errMsg += "Please choose a viewing preference.\n";
  }
  if (errMsg != "") {
    alert(errMsg);
    document.getElementById("results").innerHTML = "";
    return false;
  }

  /* The rules: genre first, then age group and viewing preference */
  if (genre == "Animation") {
    movieId = 2;
    if (age == "Child") {
      movieId = 1;
    }
  } else if (genre == "Comedy") {
    movieId = 3;
    if (age == "Adult" && (viewing == "Date Night" || viewing == "Friends")) {
      movieId = 4;
    }
  } else if (genre == "Action") {
    movieId = 5;
    if (age == "Child" || viewing == "Family") {
      movieId = 6;
    }
  } else {
    movieId = 7;
    if (age == "Adult" && viewing == "Solo") {
      movieId = 8;
    }
  }

  /* Show the result. The link carries the movie id to the booking page. */
  document.getElementById("results").innerHTML =
    "<h2>We recommend</h2>" +
    "<article class=\"result\">" +
    "<img src=\"images/movie" + movieId + ".jpg\" width=\"100\" height=\"150\" alt=\"Poster for " + titles[movieId - 1] + "\">" +
    "<div><h3>" + titles[movieId - 1] + "</h3>" +
    "<p>Ticket price: $" + prices[movieId - 1] + ".00</p>" +
    "<p>Chosen for: " + genre + ", " + age + ", " + viewing + ".</p>" +
    "<a class=\"btn\" href=\"booking.html?movie=" + movieId + "\">Book this movie</a></div>" +
    "</article>";

  return false;   /* stay on this page */
}


/* ---------- Registration page ---------- */

function validateRegister() {
  var username = document.getElementById("username").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  var country = document.getElementById("country").value;
  var gender = document.getElementById("genderFemale").checked || document.getElementById("genderMale").checked ||
    document.getElementById("genderOther").checked || document.getElementById("genderNone").checked;
  var genre = document.getElementById("genreAction").checked || document.getElementById("genreComedy").checked ||
     document.getElementById("genreAnimation").checked || document.getElementById("genreDrama").checked;
  var errMsg = "";
  var result = true;

  if (username == "" || email == "" || phone == "" || password == "" || confirmPassword == "" || country == "") {
    errMsg += "All fields must be completed.\n";
  }
  if (username.match(/^\w{5,}$/) == null) {
    errMsg += "Username must be at least 5 characters, using letters, numbers and underscores only.\n";
  }
  if (email.indexOf("@") < 1 || email.indexOf(".") < 0) {
    errMsg += "Email must be a valid email address.\n";
  }
  if (phone.match(/^\d{8,15}$/) == null) {
    errMsg += "Phone number must be 8 to 15 digits, digits only.\n";
  }
  if (password.length < 10 || password.match(/[A-Z]/) == null || password.match(/[a-z]/) == null ||
      password.match(/\d/) == null || password.match(/[^A-Za-z0-9]/) == null) {
    errMsg += "Password must be at least 10 characters with an uppercase letter, a lowercase letter, a number and a special character.\n";
  }
  if (password != confirmPassword) {
    errMsg += "Passwords do not match.\n";
  }
  if (!gender) {
    errMsg += "A gender must be selected.\n";
  }
  if (!genre) {
    errMsg += "At least one preferred genre must be selected.\n";
  }

  if (errMsg != "") {
    alert(errMsg);
    result = false;
  }
  return result;
}


/* ---------- Booking page ---------- */

/* Shows the price of the selected movie and the total cost */
function updatePrice() {
  var id = document.getElementById("movie").value;
  var tickets = parseInt(document.getElementById("tickets").value);
  var price = 0;
  var total = 0;

  if (id != "") {
    price = prices[id - 1];
  }
  if (tickets > 0) {
    total = price * tickets;
  }
  document.getElementById("ticketprice").value = "$" + price + ".00";
  document.getElementById("totalcost").value = "$" + total + ".00";
}

/* Shows the voucher box or the credit card boxes, depending on the payment method */
function updatePayment() {
  document.getElementById("voucherSection").className = "hidden";
  document.getElementById("cardSection").className = "hidden";
  if (document.getElementById("payVoucher").checked) {
    document.getElementById("voucherSection").className = "";
  }
  if (document.getElementById("payOnline").checked) {
    document.getElementById("cardSection").className = "";
  }
}

/* Copies the email into the billing email box when "Same as email address" is ticked */
function updateBillingEmail() {
  if (document.getElementById("sameEmail").checked) {
    document.getElementById("billingemail").value = document.getElementById("email").value;
  }
}

function validateBooking() {
  var fullname = document.getElementById("fullname").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var movie = document.getElementById("movie").value;
  var screening = document.getElementById("screening").value;
  var tickets = document.getElementById("tickets").value;
  var ticketType = document.getElementById("tickettype").value;
  var voucher = document.getElementById("voucher").value;
  var cardType = document.getElementById("cardtype").value;
  var cardNumber = document.getElementById("cardnumber").value;
  var billingEmail = document.getElementById("billingemail").value;
  var payVoucher = document.getElementById("payVoucher").checked;
  var payOnline = document.getElementById("payOnline").checked;
  var errMsg = "";
  var result = true;

  if (fullname == "" || email == "" || phone == "" || movie == "" || screening == "" || tickets == "" || ticketType == "") {
    errMsg += "All required fields must be completed.\n";
  }
  if (email.indexOf("@") < 1 || email.indexOf(".") < 0) {
    errMsg += "Email must be a valid email address.\n";
  }
  if (phone.match(/^\d{10,10}$/) == null) {
    errMsg += "Phone number must contain at least 10 digits, digits only.\n";
  }
  if (screening != "" && new Date(screening) < new Date()) {
    errMsg += "The screening date and time cannot be in the past.\n";
  }
  if (tickets != "" && (isNaN(tickets) || tickets <= 0)) {
    errMsg += "Number of tickets must be greater than 0.\n";
  }

  if (payVoucher) {
    if (voucher.match(/^\d{12,12}$/) == null) {
      errMsg += "Voucher code must be exactly 12 digits.\n";
    }
  } else if (payOnline) {
    if (cardType == "") {
      errMsg += "Please select a card type.\n";
    }
    if (cardNumber.match(/^\d+$/) == null) {
      errMsg += "Card number must contain digits only.\n";
    } else if (cardType == "Amex" && cardNumber.length != 15) {
      errMsg += "An Amex card number must be 15 digits.\n";
    } else if ((cardType == "Visa" || cardType == "Mastercard") && cardNumber.length != 16) {
      errMsg += "A Visa or Mastercard number must be 16 digits.\n";
    }
    if (billingEmail.indexOf("@") < 1 || billingEmail.indexOf(".") < 0) {
      errMsg += "Billing email must be a valid email address.\n";
    }
  } else {
    errMsg += "Please choose a payment method.\n";
  }

  if (errMsg != "") {
    alert(errMsg);
    result = false;
  }
  return result;
}

function initBooking() {
  /* Pre-fill the movie. The movies and recommend pages link to booking.html?movie=ID,
    so look for "movie=" and a digit in the address. found[1] is that digit. */
  var found = window.location.href.match(/movie=(\d)/);
  if (found != null && found[1] >= 1 && found[1] <= 8) {
    document.getElementById("movie").value = found[1];
  }

  document.getElementById("movie").onchange = updatePrice;
  document.getElementById("tickets").onchange = updatePrice;
  document.getElementById("tickets").onkeyup = updatePrice;
  document.getElementById("payVoucher").onclick = updatePayment;
  document.getElementById("payOnline").onclick = updatePayment;
  document.getElementById("sameEmail").onclick = updateBillingEmail;
  document.getElementById("email").onchange = updateBillingEmail;
  document.getElementById("bookingForm").onsubmit = validateBooking;

  updatePrice();
  updatePayment();
}


/* ---------- Start up: link each page's form to its function ---------- */

function init() {
  if (document.getElementById("recommendForm") != null) {
    document.getElementById("recommendForm").onsubmit = recommend;
  }
  if (document.getElementById("registerForm") != null) {
    document.getElementById("registerForm").onsubmit = validateRegister;
  }
  if (document.getElementById("bookingForm") != null) {
    initBooking();
  }
}

window.onload = init;
